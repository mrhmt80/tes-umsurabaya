<?php get_header();?>
        <div class="col-md-8 blog-main">
          <div class="blog-post">
            <h2>MAAF Halaman Tidak Ditemukan !</h2>
            <hr>
			<p>URL yang anda masukkan salah. Silahkan pilih lewat menu!</p>
          </div> <!--End blog-post-->
         </div> <!--End blog-main--> 
		<?php get_sidebar();?>	         
<?php get_footer();?>