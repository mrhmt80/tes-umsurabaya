    </div> <!--End row-->
    </main>
    <footer class="footer">
      <div class="container">
      <center>
        <span class="text-muted">Copyright&copy; <?php echo date("Y");?> UM SURABAYA</span>
        </center>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Fungsi JS -->
    <script src="<?php bloginfo('template_url');?>/bs4/js/jquery-3.3.1.slim.min.js"></script>
    <script src="<?php bloginfo('template_url');?>/bs4/js/popper.min.js"></script>
    <script src="<?php bloginfo('template_url');?>/bs4/js/bootstrap.min.js"></script>
  </body>
</html>